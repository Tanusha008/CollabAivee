// Event listener for "Get Started" button
document.getElementById('get-started-btn').onclick = function() {
    // Hide the landing page, show the sign-in page
    document.getElementById('landing-page').style.display = 'none';
    document.getElementById('sign-in-page').style.display = 'block';
};

// Event listener for Sign-In Buttons (Author/Publisher)
document.getElementById('author-sign-in-btn').onclick = function() {
    // Hide sign-in page, show the details page (for Author)
    document.getElementById('sign-in-page').style.display = 'none';
    document.getElementById('details-page').style.display = 'block';
};

document.getElementById('publisher-sign-in-btn').onclick = function() {
    // Hide sign-in page, show the details page (for Publisher)
    document.getElementById('sign-in-page').style.display = 'none';
    document.getElementById('details-page').style.display = 'block';
};

// Handling form submission on Details Page
document.getElementById('continue-btn').onclick = function() {
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const otp = document.getElementById('otp').value;

    if (name && phone && otp) {
        // Hide details page and display the appropriate section (Author or Publisher)
        document.getElementById('details-page').style.display = 'none';
        const isAuthor = document.getElementById('author-sign-in-btn').clicked;
        
        if (isAuthor) {
            document.getElementById('author-section').style.display = 'block';
        } else {
            document.getElementById('publisher-section').style.display = 'block';
        }

        // Show the review popup
        showReviewPopup();
    } else {
        alert('Please fill all fields correctly.');
    }
};

// Show the review popup after a delay
function showReviewPopup() {
    setTimeout(function() {
        document.getElementById('review-popup').style.display = 'block';
    }, 5000);  // The popup shows after 5 seconds of being in the Author/Publisher section
}

document.getElementById('close-review-btn').onclick = function() {
    document.getElementById('review-popup').style.display = 'none';
};

// Optional: A button to navigate home or refresh the page (not necessary, just an idea)
document.getElementById('home-btn').onclick = function() {
    window.location.reload();
};

